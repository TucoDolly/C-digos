package br.edu.ifsc.iprrepeticao.util;

import java.util.Scanner;

public class Util {
    public static int lerInt() {
        Scanner in = new Scanner(System.in);
        int a;
        a = in.nextInt();
        return a;
    }    
    
}
